namespace Infrastructure.RabbitMq;

public enum ExchangeEnum
{
    UserEntityRequestsExchange
}