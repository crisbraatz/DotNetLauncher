namespace Infrastructure.RabbitMq;

public enum QueueEnum
{
    UserEntityRequestsQueue
}