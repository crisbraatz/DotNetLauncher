namespace Domain.DTOs;

public abstract class BaseDataForListResponseDto : BaseListDto;