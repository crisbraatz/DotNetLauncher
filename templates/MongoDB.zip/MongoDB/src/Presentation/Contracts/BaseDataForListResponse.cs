namespace Presentation.Contracts;

/// <summary>
/// Base data for list response.
/// </summary>
public abstract record BaseDataForListResponse : BaseList;