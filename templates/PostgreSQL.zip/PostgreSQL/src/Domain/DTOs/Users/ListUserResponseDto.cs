namespace Domain.DTOs.Users;

public class ListUserResponseDto : BaseDataForListResponseDto
{
    public string Email { get; init; }
}